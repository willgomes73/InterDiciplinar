<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <ul>
            <li>
                <a href="">Alunos</a>
            </li>
            <li>
                <a href="./Professor/listar.php">Professores</a>
            </li>
            <li>
                <a href="">Disciplinas</a>
            </li>
            <li>
                <a href="">Matriculas</a>
            </li>
        </ul>
        <?php
        // put your code here
        ?>
    </body>
</html>
